package com.example.pizza.service;

import com.example.pizza.domain.PizzaMenu;
import com.example.pizza.exception.UserAlreadyExistException;
import com.example.pizza.exception.UserNoFoundException;
import com.example.pizza.repository.MenuRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class MenuServiceImpl implements MenuService {
    public MenuRepository menuRepository;

    @Autowired
    public MenuServiceImpl(MenuRepository menuRepository) {

        this.menuRepository = menuRepository;
    }


    @Override
    public PizzaMenu savePizza(PizzaMenu pizzaMenu) throws UserAlreadyExistException {
        if (menuRepository.findById(pizzaMenu.getId()).isPresent()) {
            throw new UserAlreadyExistException();
        }

        return menuRepository.save(pizzaMenu);
    }
    @Override
    public PizzaMenu getMenuById(int id) {
        return menuRepository.findById(id).get();

    }

    @Override
    public List<PizzaMenu> getAllPizzaMenu() throws UserNoFoundException {
        if(menuRepository.findAll().isEmpty())
        {
            throw new UserNoFoundException();
        }
        return menuRepository.findAll();
    }
    }
