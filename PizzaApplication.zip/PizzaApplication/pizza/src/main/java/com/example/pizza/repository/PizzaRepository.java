package com.example.pizza.repository;

import com.example.pizza.domain.User;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PizzaRepository extends MongoRepository<User,String> {
//    @Query("{'rating':{$gt:?0}}")
//    public List<Track> getAllPizzaAddedToCartThenByEmail(int rating);
//    @Query("{'pizza.':{$in:[?0]}}")
//    public List<Track> findAllTrackByArtistName(String artistName);
}
