package com.example.pizza.service;

import com.example.pizza.domain.Pizza;
import com.example.pizza.domain.User;
import com.example.pizza.exception.UserAlreadyExistException;
import com.example.pizza.exception.UserNoFoundException;
import com.example.pizza.repository.PizzaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
@Service
public class PizzaServiceImpl implements PizzaService {

    public PizzaRepository pizzaRepository;

    @Autowired
    public PizzaServiceImpl(PizzaRepository pizzaRepository) {
        this.pizzaRepository = pizzaRepository;
    }

    @Override
    public User saveUser(User user) throws UserAlreadyExistException {
        if (pizzaRepository.findById(user.getEmail()).isPresent()) {
            throw new UserAlreadyExistException();
        }

        return pizzaRepository.save(user);
    }

    @Override
    public User saveAllPizzaAddedToCartByEmail(List<Pizza> pizza, String email) throws UserNoFoundException {
        //  check user is present or not
        if (pizzaRepository.findById(email).isEmpty()) {
            throw new UserNoFoundException();
        }
        // user present
        User result = pizzaRepository.findById(email).get();
        if (result.getPizza() != null) {
            result.setPizza(pizza);
        } else {
            result.setPizza(new ArrayList<>());
            result.setPizza(pizza);
        }
        pizzaRepository.save(result);
        return result;
    }

    @Override
    public List<Pizza> getAllPizza(String email) throws UserNoFoundException {
        //check user is exist or not

        if (pizzaRepository.findById(email).isEmpty()) {
            throw new UserNoFoundException();
        }
        //if not exist
        List<Pizza> allPizza = pizzaRepository.findById(email).get().getPizza();
//        List<Pizza> ordered = new ArrayList<>();
//        for (Pizza pizza : allPizza) {
//            if (!pizza.isOrdered()) {
//                ordered.add(pizza);
//            }
//
//        }
        return allPizza;
    }
}
