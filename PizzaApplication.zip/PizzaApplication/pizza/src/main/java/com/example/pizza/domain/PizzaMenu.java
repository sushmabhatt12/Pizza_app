package com.example.pizza.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;

@Document
@NoArgsConstructor
@AllArgsConstructor
@Data
@ToString
public class PizzaMenu {

        @Id
        private int id;
        private String pizzaName;
        private String origin;
        private String description;
        private String size;
        private int rate;

    }