package com.example.pizza.controller;

import com.example.pizza.domain.PizzaMenu;
import com.example.pizza.domain.User;
import com.example.pizza.exception.UserAlreadyExistException;
import com.example.pizza.exception.UserNoFoundException;
import com.example.pizza.service.MenuService;
import com.example.pizza.service.PizzaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
@RestController
@RequestMapping("/api/pizzaService")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class MenuController {


        private MenuService menuService;
        private ResponseEntity<?> responseEntity;

        @Autowired
        public MenuController(MenuService menuService) {
            this.menuService = menuService;
        }
        @PostMapping("/menu")
        public ResponseEntity<?> saveUser(@RequestBody PizzaMenu pizzaMenu) throws UserAlreadyExistException {
            try {
                responseEntity =  new ResponseEntity<>(menuService.savePizza(pizzaMenu), HttpStatus.CREATED);
            }
            catch(UserAlreadyExistException e)
            {
                throw new UserAlreadyExistException();
            }
            return responseEntity;
        }
    @GetMapping("/menu/{id}")
    public ResponseEntity<?> getMenuById(@PathVariable int id) throws UserNoFoundException {
        return new ResponseEntity<>(menuService.getMenuById(id),HttpStatus.OK);
    }
    @GetMapping("/menu")
    public ResponseEntity<?> getAllBook()  throws UserNoFoundException {
        return new ResponseEntity<>(menuService.getAllPizzaMenu(),HttpStatus.OK);
    }
    }
