package com.example.pizza.service;

import com.example.pizza.domain.PizzaMenu;
import com.example.pizza.exception.UserAlreadyExistException;
import com.example.pizza.exception.UserNoFoundException;

import java.util.List;

public interface MenuService {
    PizzaMenu savePizza(PizzaMenu pizzaMenu) throws UserAlreadyExistException;
    public List<PizzaMenu> getAllPizzaMenu()  throws UserNoFoundException;
    public PizzaMenu getMenuById(int id) throws UserNoFoundException;
//    public PizzaMenu addToCart(PizzaMenu pizzaMenu, String pizzaName);
}
