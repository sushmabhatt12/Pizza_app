package com.example.pizza.repository;

import com.example.pizza.domain.PizzaMenu;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MenuRepository extends MongoRepository<PizzaMenu,Integer> {
}