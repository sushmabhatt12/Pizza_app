package com.bej.users.service;

import com.bej.users.model.User;

import java.util.Map;

public interface ISecurityTokenGenerator {
    public Map<String, String> tokenGenerator(User user);
}
