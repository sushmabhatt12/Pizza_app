package com.bej.users.controller;


import com.bej.users.model.User;

import com.bej.users.service.ISecurityTokenGenerator;
import com.bej.users.service.ISecurityTokenGeneratorImpl;
import com.bej.users.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/userService")
@CrossOrigin
public class UserController {
    private ISecurityTokenGenerator iSecurityTokenGenerator;
    private UserService userService;
    @Autowired
    public UserController(ISecurityTokenGenerator iSecurityTokenGenerator, UserService userService) {
        this.iSecurityTokenGenerator = iSecurityTokenGenerator;
        this.userService = userService;
    }

    @PostMapping("/register")
    public ResponseEntity<?> saveUser(@RequestBody User user){
            return new ResponseEntity<>(userService.saveUser(user), HttpStatus.CREATED);
    }
    @PostMapping("/login")
    public ResponseEntity<?> loginCheck(@RequestBody User user){
        User result = userService.loginCheck(user.getEmail(), user.getPassword());
    if(result!=null){
        Map<String, String> map=iSecurityTokenGenerator.tokenGenerator(result);
   return new ResponseEntity<>(map,HttpStatus.OK);
    }else{
        return new ResponseEntity<>("invalid user or user doesn't exist",HttpStatus.NOT_FOUND);
    }
    }


    @GetMapping("/users")
    public ResponseEntity<?> getAllUsers() {

        return new ResponseEntity<>(userService.getAllUsers(), HttpStatus.FOUND);
    }
    @GetMapping("/users/{lastName}")
    public ResponseEntity<?> getAllUsersByLastName(@PathVariable String lastName) {
        return new ResponseEntity<>(userService.getUserByLastName(lastName), HttpStatus.FOUND);
    }
    @DeleteMapping("/user/{email}")
    public ResponseEntity<?> deleteUser(@PathVariable String email){
        return new ResponseEntity<>(userService.deleteUserByEmail(email), HttpStatus.OK);
    }
    @PutMapping("/user/{email}")
    public ResponseEntity<?> updateUser(@RequestBody User user,@PathVariable String email) {
        return new ResponseEntity<>(userService.updateUser(user,email), HttpStatus.OK);
    }


}
