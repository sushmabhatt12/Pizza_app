package com.example.UserOrder;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserOrderApplicationTests {

	@Test
	void contextLoads() {
	}

}
