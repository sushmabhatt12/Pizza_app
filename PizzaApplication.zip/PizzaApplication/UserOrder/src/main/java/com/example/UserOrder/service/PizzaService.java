package com.example.UserOrder.service;

import com.example.UserOrder.domain.Pizza;
import com.example.UserOrder.domain.User;
import com.example.UserOrder.exception.UserAlreadyExistException;
import com.example.UserOrder.exception.UserNoFoundException;

import java.util.List;

public interface PizzaService {
    User saveUser(User user) throws UserAlreadyExistException;
    User saveAllPizzaAddedToCartByEmail(List<Pizza> pizza, String email) throws UserNoFoundException;
    List<Pizza> getAllPizza(String email) throws UserNoFoundException;

    //Login user can view, choose & Order Pizza & other items
}
