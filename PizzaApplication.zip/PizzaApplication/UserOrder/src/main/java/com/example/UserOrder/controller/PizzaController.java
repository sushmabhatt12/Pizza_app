package com.example.UserOrder.controller;

import com.example.UserOrder.domain.Pizza;
import com.example.UserOrder.domain.User;
import com.example.UserOrder.exception.UserAlreadyExistException;
import com.example.UserOrder.exception.UserNoFoundException;
import com.example.UserOrder.service.PizzaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/pizzaService")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class PizzaController {
    private PizzaService pizzaService;
    private ResponseEntity<?> responseEntity;

    @Autowired
    public PizzaController(PizzaService pizzaService) {
        this.pizzaService = pizzaService;
    }
    @PostMapping("/pizza")
    public ResponseEntity<?> saveUser(@RequestBody User user) throws UserAlreadyExistException {
        try {
            responseEntity =  new ResponseEntity<>(pizzaService.saveUser(user), HttpStatus.CREATED);
        }
        catch(UserAlreadyExistException e)
        {
            throw new UserAlreadyExistException();
        }
        return responseEntity;
    }


    @PostMapping("/pizza/{email}")
    public ResponseEntity<?> saveAllPizzaAddedToCartByEmail(@RequestBody List<Pizza> pizza, @PathVariable String email) throws UserNoFoundException {
        try {
            responseEntity = new ResponseEntity<>(pizzaService.saveAllPizzaAddedToCartByEmail(pizza, email), HttpStatus.CREATED);
        } catch (UserNoFoundException e) {
            throw new UserNoFoundException();
        }
        return responseEntity;
    }
        @GetMapping("/pizza/{email}")
        public ResponseEntity<?> getAllPizza(@PathVariable String email) throws UserNoFoundException {
        return new ResponseEntity<>(pizzaService.getAllPizza(email),HttpStatus.OK);

    }
}
