package com.example.UserOrder.repository;

import com.example.UserOrder.domain.User;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PizzaRepository extends MongoRepository<User,String> {
//    @Query("{'rating':{$gt:?0}}")
//    public List<Track> getAllPizzaAddedToCartThenByEmail(int rating);
//    @Query("{'pizza.':{$in:[?0]}}")
//    public List<Track> findAllTrackByArtistName(String artistName);
}
